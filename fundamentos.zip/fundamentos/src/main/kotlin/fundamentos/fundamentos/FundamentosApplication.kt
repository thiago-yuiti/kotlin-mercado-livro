package fundamentos.fundamentos

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class FundamentosApplication

fun main(args: Array<String>) {
	runApplication<FundamentosApplication>(*args)
}
